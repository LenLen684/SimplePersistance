package com.company;

import com.company.model.Employee;

import java.io.*;
import java.util.*;

public class main {

    public static void main(String[] args) {
        long startTime = System.nanoTime();
        // printPeopleDetails("C:\\Users\\Yaksh Patel\\Downloads\\People Records\\people\\simple");
        // printEmployees("C:\\Users\\Yaksh Patel\\Downloads\\People Records\\people\\simple");
        //addEmployee(40,"new","person",2020);
        //deleteEmployee(40);
        //serializeAllEmployees();
        //getSerializedEmployee(2);
        //findEmployeeByLastName("HOWARD");
        //printAllEmployees();
        printSerializedDetails("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized");
        long endTime = System.nanoTime() - startTime;
        System.out.println(endTime + "");
    }

    public static void printPeopleDetails(String path){
        File dir = new File(path);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                Scanner myReader = null;
                try {
                    myReader = new Scanner(child);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    System.out.println(data);
                }
                myReader.close();
            }
        } else {
            System.out.println("Directory has no files");
        }
    }

    public static void printEmployees(String path){
        File dir = new File(path);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                Scanner myReader = null;
                try {
                    myReader = new Scanner(child);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    String[] array = data.split(",");

                    int id = Integer.parseInt(array[0].trim());
                    String first = array[1].trim();
                    String last = array[2].trim();
                    int hireYear = Integer.parseInt(array[3].trim());

                    Employee employee = new Employee(id,hireYear,first,last);
                    System.out.println(employee.toString());
                }
                myReader.close();
            }
        } else {
            System.out.println("Directory has no files");
        }
    }

    public static void addEmployee(int id, String firstName, String lastName, int hireYear){
        String filename = id + ".txt";
        String content = id +"," + firstName+"," + lastName+"," + hireYear;
        File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long/" + filename);

        try {
            if (file.createNewFile()) {
                System.out.println("File has been created.");
            } else {

                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter(file);
            myWriter.write(content);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void deleteEmployee(int id){
        File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long/" + id + ".txt");
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("Deleted the file: " + file.getName());
            } else {
                System.out.println("Failed to delete the file.");
            }
        }
    }

    public static void updateEmployee(int id, String firstName, String lastName, int hireYear){
        String filename = id + ".txt";
        String content = id +"," + firstName+"," + lastName+"," + hireYear;
        File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long/" + filename);
        if (file.exists()) {
            try {
                FileWriter myWriter = new FileWriter(file);
                myWriter.write(content);
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

    public static void serializeAllEmployees(){
        File dir = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long");
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                Scanner myReader = null;
                try {
                    myReader = new Scanner(child);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    String[] array = data.split(",");

                    int id = Integer.parseInt(array[0].trim());
                    String first = array[1].trim();
                    String last = array[2].trim();
                    int hireYear = Integer.parseInt(array[3].trim());

                    Employee employee = new Employee(id,hireYear,first,last);
                    //System.out.println(employee.toString());
                    File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized/" + id + ".ser");

                    try {
                        if (file.createNewFile()) {
                            System.out.println("File has been created.");
                        } else {

                            System.out.println("File already exists.");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // Serialization
                    try
                    {
                        //Saving of object in a file
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        ObjectOutputStream out = new ObjectOutputStream(fileOutputStream);

                        // Method for serialization of object
                        out.writeObject(employee);

                        out.close();
                        fileOutputStream.close();

                        System.out.println("Object has been serialized");

                    }

                    catch(IOException ex)
                    {
                        System.out.println("IOException is caught");
                    }


                }
                myReader.close();
            }
        } else {
            System.out.println("Directory has no files");
        }
    }

    public static void getSerializedEmployee(int id){
        File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized/" + id + ".ser");
        if (file.exists()) {
            // Deserialization
            try
            {
                // Reading the object from a file
                FileInputStream fileis = new FileInputStream(file);
                ObjectInputStream in = new ObjectInputStream(fileis);

                // Method for deserialization of object
                Employee employee = (Employee) in.readObject();

                in.close();
                fileis.close();

                System.out.println(employee.toString());
            }

            catch(IOException ex)
            {
                System.out.println("IOException is caught");
            }

            catch(ClassNotFoundException ex)
            {
                System.out.println("ClassNotFoundException is caught");
            }
        }
    }

    public static Employee findEmployeeById(int id){
        File file = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized/" + id + ".ser");
        Employee employee = null;
        if (file.exists()) {
            // Deserialization
            try
            {
                // Reading the object from a file
                FileInputStream fileis = new FileInputStream(file);
                ObjectInputStream in = new ObjectInputStream(fileis);

                // Method for deserialization of object
                employee = (Employee) in.readObject();

                in.close();
                fileis.close();
            }

            catch(IOException ex)
            {
                System.out.println("IOException is caught");
            }

            catch(ClassNotFoundException ex)
            {
                System.out.println("ClassNotFoundException is caught");
            }
        }
        return employee;
    }

    public static List<Employee> findEmployeeByLastName(String lastName){
        List<Employee> employees = new ArrayList<>();
        File dir = new File("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized");
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                // Deserialization
                try
                {
                    // Reading the object from a file
                    FileInputStream fileis = new FileInputStream(child);
                    ObjectInputStream in = new ObjectInputStream(fileis);

                    // Method for deserialization of object
                    Employee temp = (Employee) in.readObject();
                    if (temp.getLastName().equals(lastName)){
                        employees.add(temp);
                    }
                    in.close();
                    fileis.close();
                }

                catch(IOException ex)
                {
                    System.out.println("IOException is caught");
                }

                catch(ClassNotFoundException ex)
                {
                    System.out.println("ClassNotFoundException is caught");
                }
            }
        } else {
            System.out.println("Directory has no files");
        }

        return employees;
    }

    public static void printSerializedDetails(String path){
        File dir = new File(path);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                // Deserialization
                try
                {
                    // Reading the object from a file
                    FileInputStream fileis = new FileInputStream(child);
                    ObjectInputStream in = new ObjectInputStream(fileis);

                    // Method for deserialization of object
                    Employee temp = (Employee) in.readObject();
                    System.out.println(temp.toString());
                    in.close();
                    fileis.close();
                }

                catch(IOException ex)
                {
                    System.out.println("IOException is caught");
                }

                catch(ClassNotFoundException ex)
                {
                    System.out.println("ClassNotFoundException is caught");
                }
            }
        } else {
            System.out.println("Directory has no files");
        }
    }

    public static HashMap<Integer,Employee> getAllEmployees(String path){
        HashMap<Integer,Employee> employeeMap = new HashMap<>();
        File dir = new File(path);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                // Deserialization
                try
                {
                    // Reading the object from a file
                    FileInputStream fileis = new FileInputStream(child);
                    ObjectInputStream in = new ObjectInputStream(fileis);

                    // Method for deserialization of object
                    Employee temp = (Employee) in.readObject();
                    employeeMap.put(temp.getId(),temp);
                    in.close();
                    fileis.close();
                }

                catch(IOException ex)
                {
                    System.out.println("IOException is caught");
                }

                catch(ClassNotFoundException ex)
                {
                    System.out.println("ClassNotFoundException is caught");
                }
            }
        } else {
            System.out.println("Directory has no files");
        }
        return employeeMap;
    }

    public static void printAllEmployees(){
        HashMap<Integer,Employee> employeeHashMap = getAllEmployees("C:/Users/Yaksh Patel/Downloads/People Records/people/long serialized");
        for (Map.Entry<Integer, Employee> entry : employeeHashMap.entrySet()) {
            Employee value = entry.getValue();
            System.out.println(value.toString());
        }
    }
}
